import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flutter/widgets.dart';
import 'dart:math';

import 'bird.dart';
import 'pipe.dart';

const speed = 80;
const gapInSeconds = 3.5;
const gravity = 900;


class MyGame extends FlameGame with TapDetector, HasCollisionDetection {
  late Bird character;
  late double baseHeight;
  late Sprite baseSprite;
  late Sprite? myPipeSprite;
  double delta = 0;
  final List<SpriteComponent> bases = [];
  String birdSprite = 'yellowbird-midflap.png';
  String pipeSprite = 'pipe-green.png';

  final Function() onGameOver;

  MyGame({
    required this.onGameOver,
    required this.birdSprite,
    required this.pipeSprite,
    });

  @override
  Future<void> onLoad() async {
    super.onLoad();

    final sprite = await loadSprite('background-day.png');

    myPipeSprite = await loadSprite(pipeSprite);

    final background1 = SpriteComponent()..sprite = sprite;
  
    baseSprite = await loadSprite('base.png');
    final base1 = SpriteComponent()..sprite = baseSprite;
    final base2 = SpriteComponent()..sprite = baseSprite;
    baseHeight = base1.size.y;
    Size screenSize = WidgetsBinding.instance.window.physicalSize;
    double width = screenSize.width;
    double height = screenSize.height;

    background1.size = Vector2(width, (height-base1.size.y));

    add(background1);

 

    character = Bird(
      position: Vector2(100, size.y / 2),
      size: Vector2(50, 35),
      bottom: (size.y - baseHeight / 2),
      spriteName: birdSprite,
      onGameOver: onGameOver,
    )..debugMode = true;
    /*
    Pipe pipe =
        Pipe(position: Vector2((size.x / 2)+50, size.y+100), size: Vector2(100, 400))
          ..debugMode = true;
    Pipe pipe2 =
        Pipe(position: Vector2((size.x / 2)+50, (size.y/2)-100), size: Vector2(100, 400), isTop: true)
        ..debugMode = true;
    */
    add(character);
    /*
    add(pipe);
    add(pipe2);
    */
    reloadBases();
  }

  @override
  void onTapDown(TapDownInfo info) {
    character.jump();
  }

  @override
  void update(double dt) {
    delta += dt;
    var rng = Random(); //650
    var randomInt = rng.nextInt(330);
    double pipeOffset = (randomInt-165);

    if (delta > gapInSeconds) {
      delta %= gapInSeconds;
      final newPipe =
          Pipe(position: Vector2((size.x+50), size.y+110+pipeOffset), size: Vector2(100, 400), sprite: myPipeSprite!);
      final newPipe2 =
          Pipe(position: Vector2((size.x+50), (size.y/2)-110+pipeOffset), size: Vector2(100, 400), isTop: true, sprite: myPipeSprite!);
      add(newPipe);
      add(newPipe2);
      reloadBases();
    }

    super.update(dt);
  }

  void reloadBases() {
    for (final base in bases) {
      base.removeFromParent();
    }
    bases.clear();

    final base1 = SpriteComponent()..sprite = baseSprite;
    final base2 = SpriteComponent()..sprite = baseSprite;
    base1.position = Vector2(0, size.y - (base1.size.y / 2));
    base2.position = Vector2(base1.size.x, size.y - (base2.size.y / 2));
    bases.add(base1);
    bases.add(base2);
    add(base1);
    add(base2);
  }
}
