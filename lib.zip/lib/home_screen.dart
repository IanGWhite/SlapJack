import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'my_game.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  void gameOver() => Navigator.of(context).pop();

  String myBirdSprite = 'yellowbird-midflap.png';
  String myPipeSprite = 'pipe-green.png';


  @override
  Widget build(BuildContext context) {
    return Material(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GestureDetector(
            child: Image.asset('assets/images/message.png'),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => GameWidget(
                    game: MyGame(
                  birdSprite: myBirdSprite,
                  pipeSprite: myPipeSprite,
                  onGameOver: gameOver,
                )),
              ));
            },
          ),
          SizedBox(
            width: 250,
            child: Column(
              children: <Widget>[
                Text('Bird'),
                Column(
                  children: [ListTile(
                leading: Radio<String>(
                  value: 'yellowbird-midflap.png',
                  groupValue: myBirdSprite,
                  onChanged: (value) {
                    setState(() {
                      myBirdSprite = value!;
                    });
                  },
                ),
                title: const Text('Yellow Bird'),
              ),
              ListTile(
                leading: Radio<String>(
                  value: 'redbird-midflap.png',
                  groupValue: myBirdSprite,
                  onChanged: (value) {
                    setState(() {
                      myBirdSprite = value!;
                    });
                  },
                ),
                title: const Text('Red Bird'),
              ),
                            ListTile(
                leading: Radio<String>(
                  value: 'bluebird-midflap.png',
                  groupValue: myBirdSprite,
                  onChanged: (value) {
                    setState(() {
                      myBirdSprite = value!;
                    });
                  },
                ),
                title: const Text('Blue Bird'),
              ),]),
              
                /*
                FloatingActionButton(
                  onPressed: changeBirdSprite,
                  tooltip: 'Change Sprite',
                  child: const Icon(Icons.casino),
                ),*/
              Text('Pipe'),
              Column(
                  children: <Widget>[
              ListTile(
                leading: Radio<String>(
                  value: 'pipe-green.png',
                  groupValue: myPipeSprite,
                  onChanged: (value) {
                    setState(() {
                      myPipeSprite = value!;
                    });
                  },
                ),
                title: const Text('Green Pipe'),
              ),
              ListTile(
                leading: Radio<String>(
                  value: 'pipe-red.png',
                  groupValue: myPipeSprite,
                  onChanged: (value) {
                    setState(() {
                      myPipeSprite = value!;
                    });
                  },
                ),
                title: const Text('Red Pipe'),
              ),
              ],
            ),])
          ),
        ],
      ),
    );

    
  }


  void changeBirdSprite() {
    if(myBirdSprite == 'yellowbird-midflap.png'){
      myBirdSprite = 'redbird-midflap.png';
    }else if(myBirdSprite == 'redbird-midflap.png'){
      myBirdSprite = 'bluebird-midflap.png';
    }else {
      myBirdSprite = 'yellowbird-midflap.png';
    }
    
  }

    void changePipeSprite() {
    if(myBirdSprite == 'yellowbird-midflap.png'){
      myBirdSprite = 'redbird-midflap.png';
    }else {
      myBirdSprite = 'yellowbird-midflap.png';
    }
    
  }

}
